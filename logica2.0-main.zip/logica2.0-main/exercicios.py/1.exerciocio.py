import os 

os.system("clear") 

# Solicitando dados (Entrada)
valor = float(input("Digite o valor: "))


#Verificando(Processando)
if valor == 10:
   print("É IGUAL A 10: ")
   
if valor < 10:
   print("É MAIOR QUE 10: ")

if valor > 10:
   print("È MENOR QUE 10: ")

# Exibindo dados ( Saída )
print("== FIMSE ==")

