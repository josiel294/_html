#  Tipagem dinãnmica.
#  Quando a linguagem identifica o tipo de dado.

#  nome: caracter
nome = "Isaac"

#  idade: inteiro
idade = 17

# altura: real
altura = 1.77

# Exinond dados (Saída)
print(nome)
print(idade)
print(altura)