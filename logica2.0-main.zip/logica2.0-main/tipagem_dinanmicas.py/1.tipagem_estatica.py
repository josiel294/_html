# Tipagem estática
# Quando nesscessário informar o  tipo de variável.

# nome: caracter
nome: str
nome = "isaac"
# idade: inteiro
idade: int
idade = 17

# altura: real
altura: float
altura = 1.77

# Exibir os dados ( Sáida )
print(f"Nome: {nome}")
print(f"Idade: {idade}")
print(f"Altura: {altura}")